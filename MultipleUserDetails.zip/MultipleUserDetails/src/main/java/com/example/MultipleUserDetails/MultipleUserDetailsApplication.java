package com.example.MultipleUserDetails;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MultipleUserDetailsApplication {

	public static void main(String[] args) {
		SpringApplication.run(MultipleUserDetailsApplication.class, args);
	}
}
