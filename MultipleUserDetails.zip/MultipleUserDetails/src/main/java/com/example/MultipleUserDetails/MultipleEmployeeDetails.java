package com.example.MultipleUserDetails;

import java.io.IOException;
import java.util.ArrayList;





import javax.servlet.http.HttpServletResponse;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;





@RestController
@RequestMapping(value="/emp")
public class MultipleEmployeeDetails
{
	
	ArrayList<EmployeeList> empList=null;

	
	@GetMapping(value="/select/{id}",produces=MediaType.APPLICATION_XML_VALUE)
	public EmployeeList readEmployee(@PathVariable("id") int id)
	{
		
		
		return empList.get(id);
		
	}
	
	
	@PostMapping(value="/insertEmp",consumes=MediaType.APPLICATION_JSON_VALUE)
	public ArrayList<EmployeeList> insertEmployee(@RequestBody ArrayList<EmployeeList> emp)
	{
		empList=emp;
		
		System.out.println(emp);
		
		return empList;
		
	}
	
	/*@ExceptionHandler(Exception.class)                       (Same exception handling we are doing in global level)
	public void ErrorHandler(HttpServletResponse res)
	{
		try
		{
			res.sendRedirect("http://google.com");
		}
		
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}*/
}
